## Installation

1. Clone the Repository.
2. Upload the database schema to your localhost database.
3. Remove the classes created in the entity folder.
4. Create a persistence mapping using Hibernate form database schema.
5. Run the project.

```bash
mvn spring-boot:run
```


